const express = require('express');

const bookingControllers = require('../controllers/booking.controllers');
const authCheck = require('../middlewares/auth-check.middleware');

const router = express.Router();

router.post(
    '/book-appointment', 
    authCheck,
    bookingControllers.checkSlotAvailability,
    bookingControllers.bookAppointment
);

router.put(
    '/update-appointment/:id', 
    authCheck,
    bookingControllers.checkSlotAvailability,
    bookingControllers.updateAppointment
);

router.get(
    '/get-hosted-appointments/:host', 
    authCheck,
    bookingControllers.getHostedAppointments
);

router.get(
    '/get-guest-appointments/:guest', 
    authCheck,
    bookingControllers.getGuestAppointments
);

router.get(
    '/get-all-appointments/:user', 
    authCheck,
    bookingControllers.getAllAppointments
);

router.delete(
    '/delete-appointment/:id', 
    authCheck,
    bookingControllers.deleteAppointment
);

module.exports = router;
